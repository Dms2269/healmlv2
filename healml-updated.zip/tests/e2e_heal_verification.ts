/**
 * HEALML – Live API & SPA Route End-to-End Verification Script
 * Verifies against a running HEALML server (e.g. BASE_URL=http://127.0.0.1:3099):
 *  - SPA routes (/heal, /explorer, /detect, /updated, /overview, /admin/workstation) serve 200 HTML
 *  - Auth login for CLIENT and MASTER_ADMIN
 *  - /api/heal/versions returns v2.0 & v1.8
 *  - /api/pipeline/heal enforces 401/403/404/idempotency/simulated 500 failure + sanitized error log
 *  - /api/heal/versions/switch transitions v2.0 -> v1.8 -> v2.0 cleanly
 *  - /api/heal/history and /api/heal/errors return verified records
 */

import assert from 'node:assert';

const BASE_URL = process.env.BASE_URL || 'http://127.0.0.1:3099';

async function runE2E() {
  console.log(`--- HEALML LIVE API & SPA E2E VERIFICATION (${BASE_URL}) ---`);
  let passed = 0;
  let failed = 0;

  async function step(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`PASS: ${name}`);
      passed++;
    } catch (e: any) {
      console.error(`FAIL: ${name} ->`, e?.message || e);
      failed++;
    }
  }

  let clientToken = '';
  let otherClientToken = '';
  let adminToken = '';

  await step('E2E 1: SPA Routes (/heal, /explorer, /detect, /updated, /overview) return HTTP 200 HTML', async () => {
    for (const path of ['/heal', '/explorer', '/detect', '/updated', '/overview', '/admin/workstation']) {
      const resp = await fetch(`${BASE_URL}${path}`);
      assert.strictEqual(resp.status, 200, `Expected 200 on ${path}, got ${resp.status}`);
      const html = await resp.text();
      assert.ok(html.includes('<div id="root"></div>') || html.includes('HEALML'), `Missing SPA mount on ${path}`);
    }
  });

  await step('E2E 2: System health endpoint is ONLINE', async () => {
    const resp = await fetch(`${BASE_URL}/api/system/health`);
    assert.strictEqual(resp.status, 200);
    const data: any = await resp.json();
    assert.strictEqual(data.status, 'ONLINE');
  });

  await step('E2E 3: Auth login succeeds for Client 1, Client 2, and Master Admin', async () => {
    const login = async (email: string, password: string) => {
      const r = await fetch(`${BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      assert.strictEqual(r.status, 200, `Login failed for ${email}`);
      return (await r.json()) as any;
    };

    const c1 = await login('client1@healml.com', process.env.TEST_CLIENT_PASS || 'Alpha@2026');
    assert.strictEqual(c1.user.role, 'CLIENT');
    clientToken = c1.token;

    const c2 = await login('client2@healml.com', process.env.TEST_CLIENT_PASS || 'Beta@2026');
    assert.strictEqual(c2.user.role, 'CLIENT');
    otherClientToken = c2.token;

    const adminEmail = '2269dms@gmail.com';
    const adminPass = process.env.MASTER_ADMIN_INITIAL_PASSWORD || '2269dms';
    const adm = await login(adminEmail, adminPass);
    assert.strictEqual(adm.user.role, 'MASTER_ADMIN');
    adminToken = adm.token;
    assert.ok(clientToken && otherClientToken && adminToken);
  });

  await step('E2E 4: GET /api/heal/versions lists real v2.0 and v1.8 releases', async () => {
    const resp = await fetch(`${BASE_URL}/api/heal/versions?projectId=prj_cl_test_001`);
    assert.strictEqual(resp.status, 200);
    const data: any = await resp.json();
    assert.ok(Array.isArray(data.versions));
    assert.ok(data.versions.some((v: any) => v.id === 'v2.0'));
    assert.ok(data.versions.some((v: any) => v.id === 'v1.8'));
    assert.strictEqual(data.activeVersionId, 'v2.0');
  });

  await step('E2E 5: POST /api/pipeline/heal enforces 401, 403 cross-tenant, and 404 invalid datasetId', async () => {
    // 401 unauthenticated
    const r401 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ datasetId: 'ds_cl1_vibration_telemetry', projectId: 'prj_cl_test_001' }),
    });
    assert.strictEqual(r401.status, 401);

    // 403 cross-tenant (Client 2 trying to heal Client 1 dataset)
    const r403 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${otherClientToken}` },
      body: JSON.stringify({ datasetId: 'ds_cl1_vibration_telemetry', projectId: 'prj_cl_test_001' }),
    });
    assert.strictEqual(r403.status, 403);

    // 404 non-existent datasetId
    const r404 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({ datasetId: 'ds_non_existent_999', projectId: 'prj_cl_test_001' }),
    });
    assert.strictEqual(r404.status, 404);
  });

  await step('E2E 6: POST /api/pipeline/heal succeeds with idempotency protection and persists separate healed dataset', async () => {
    const idempKey = `idemp_e2e_${Date.now()}`;
    const payload = {
      datasetId: 'ds_cl1_vibration_telemetry',
      projectId: 'prj_cl_test_001',
      targetCol: 'failure_flag',
      healEngineVersion: 'v2.0',
      idempotencyKey: idempKey,
      issuesDetected: 4,
      repairsApplied: 4,
      qualityBefore: 81.2,
      qualityAfter: 97.5,
      verificationStatus: 'VERIFIED_SUCCESS',
      durationMs: 65,
    };

    const r1 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify(payload),
    });
    assert.strictEqual(r1.status, 200);
    const d1: any = await r1.json();
    assert.strictEqual(d1.status, 'VERIFIED_SUCCESS');
    assert.ok(d1.updatedDatasetId.startsWith('ds_healed_'));
    assert.notStrictEqual(d1.updatedDatasetId, d1.originalDatasetId);

    // Duplicate idempotencyKey request returns cached response safely
    const r2 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify(payload),
    });
    assert.strictEqual(r2.status, 200);
    const d2: any = await r2.json();
    assert.strictEqual(d2.deduplicated, true);
    assert.strictEqual(d2.updatedDatasetId, d1.updatedDatasetId);
  });

  await step('E2E 7: Switch version to v1.8, run heal with v1.8, and restore v2.0', async () => {
    const sw1 = await fetch(`${BASE_URL}/api/heal/versions/switch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({
        projectId: 'prj_cl_test_001',
        targetVersionId: 'v1.8',
        reason: 'E2E rollback test',
        compatibilityStatus: 'COMPATIBLE',
      }),
    });
    assert.strictEqual(sw1.status, 200);
    const sw1Data: any = await sw1.json();
    assert.strictEqual(sw1Data.activeVersionId, 'v1.8');

    const healV18 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({
        datasetId: 'ds_cl1_vibration_telemetry',
        projectId: 'prj_cl_test_001',
        targetCol: 'failure_flag',
        healEngineVersion: 'v1.8',
        idempotencyKey: `idemp_v18_${Date.now()}`,
        issuesDetected: 4,
        repairsApplied: 3,
        qualityBefore: 81.2,
        qualityAfter: 95.8,
        verificationStatus: 'VERIFIED_SUCCESS',
        durationMs: 44,
      }),
    });
    assert.strictEqual(healV18.status, 200);
    const healV18Data: any = await healV18.json();
    assert.strictEqual(healV18Data.healEngineVersion, 'v1.8');

    // Restore v2.0
    const sw2 = await fetch(`${BASE_URL}/api/heal/versions/switch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({
        projectId: 'prj_cl_test_001',
        targetVersionId: 'v2.0',
        reason: 'E2E restore current version',
        compatibilityStatus: 'COMPATIBLE',
      }),
    });
    assert.strictEqual(sw2.status, 200);
    assert.strictEqual(((await sw2.json()) as any).activeVersionId, 'v2.0');
  });

  await step('E2E 8: Simulated API 500 failure logs sanitized error without token leakage & /api/heal/history updates', async () => {
    const r500 = await fetch(`${BASE_URL}/api/pipeline/heal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({
        datasetId: 'ds_cl1_vibration_telemetry',
        projectId: 'prj_cl_test_001',
        healEngineVersion: 'v2.0',
        simulateFailure: true,
      }),
    });
    assert.strictEqual(r500.status, 500);
    const errData: any = await r500.json();
    assert.ok(errData.errorId && errData.errorId.startsWith('HEAL-ERR-'));
    assert.strictEqual(errData.recommendedFallbackVersion, 'v1.8');

    const unauthErrs = await fetch(`${BASE_URL}/api/heal/errors`);
    assert.strictEqual(unauthErrs.status, 401);

    const errsResp = await fetch(`${BASE_URL}/api/heal/errors`, {
      headers: { Authorization: `Bearer ${clientToken}` },
    });
    assert.strictEqual(errsResp.status, 200);
    const errsData: any = await errsResp.json();
    assert.ok(errsData.errors.some((e: any) => e.errorId === errData.errorId));

    const histResp = await fetch(`${BASE_URL}/api/heal/history?projectId=prj_cl_test_001`, {
      headers: { Authorization: `Bearer ${clientToken}` },
    });
    assert.strictEqual(histResp.status, 200);
    const histData: any = await histResp.json();
    assert.ok(histData.history.length >= 2);
    assert.ok(histData.switchLogs.length >= 2);
  });

  console.log(`\n========================================`);
  console.log(`E2E SUMMARY: ${passed} PASSED, ${failed} FAILED (TOTAL: ${passed + failed})`);
  console.log(`========================================`);
  if (failed > 0) process.exit(1);
}

runE2E();
